#!ATTRIBUTES
attribute vec4 random;

#!UNIFORMS
uniform sampler2D tPos;
uniform sampler2D tLightTexture;
uniform sampler2D tPointColor;
uniform sampler2D tMap;
uniform vec3 uLightPos;
uniform vec3 uTint;
uniform float DPR;
uniform float uScroll;
uniform float uSizeBias;
uniform float uAnimate;
uniform float uRotate;
uniform float uSparkle;

#!VARYINGS
varying vec3 vLightColor;
varying vec3 vPos;
varying vec4 vRandom;
varying float vScale;
varying float vDist;
varying float vRipple;
varying vec3 vWorldPos;
varying vec2 vUv;
varying float vOffset;
varying float vFlowers;
varying vec3 vCameraPos;

#!SHADER: Vertex

const float PI = 3.1415926535897932384626433832795;

#require(range.glsl)
#require(lighting.vs)
#require(simplenoise.glsl)

void main() {
    vec4 decodedPos = texture2D(tPos, position.xy);
    vec3 pos = decodedPos.xyz;

    vCameraPos = cameraPosition;


    //vFlowers = pos.z > 0.5 ? 1.0 : 0.0;

    if (pos.x < 0.0) {
        pos.z = -pos.z;
        pos.y -= 5.0;
    }

    pos.x += 1.0;
    pos.z -= 0.5;

    float offset = smoothstep(0.4, 0.0, uScroll) * pow(random.x, 30.0) * 10.0;
    offset *= (0.8 + sin(pos.y * 0.2 + time * 0.02 + uScroll + random.z * 2.0) * 0.2);
    pos.y += offset;

    // Top Spiral
    pos.x -= cos(uScroll * 5.0 + length(pos.xz) * 1.0 + pos.y * 0.5 + uRotate * 2.0) * 0.5 * smoothstep(0.0, 0.5, abs(uScroll-0.5));
    pos.z -= sin(uScroll * 5.0 + length(pos.xz) * 1.0 + pos.y * 0.5 + uRotate * 2.0) * 0.5 * smoothstep(0.0, 0.5, abs(uScroll-0.5));

    // RotateTransition
    float radius = 3.0;
    //pos.x -= (cos(uRotate) * radius) - radius * 2.0;
    //pos.z -= (sin(uRotate) * radius) - radius * 2.0;

    // Outer Spiral
    radius = mix(0.5, 3.0, pow(random.w, 2.0));
    pos.x -= cos(pos.y * 0.5 + sin(time * 0.05 + random.w * 5.0 * 0.1 - uRotate * 0.2)) * 25.0 * step(0.95, random.y);
    pos.z -= sin(pos.y * 0.5 + sin(time * 0.05 + random.w * 5.0 * 0.1 - uRotate * 0.2)) * 25.0 * step(0.95, random.y);

    if (pos.x < 0.0) {
        pos.x -= cos(-decodedPos.y * 0.06) * 3.0 - 3.5;
        pos.z -= sin(-decodedPos.y * 0.06) * 3.0 - 2.0;
    } else {
        pos.x -= cos(-decodedPos.y * 0.06 + 3.0) * 3.0 + 3.5;
        pos.z -= sin(-decodedPos.y * 0.06 + 3.0) * 3.0 + 1.0;
    }

    // Bottom Spiral
    pos.y -= pow(uScroll, 4.0) * 20.0 * pow(random.w, 15.0);
    pos.x -= cos(pos.y * 1.0) * 0.2 * pow(random.w, 4.0) * pow(uScroll, 3.5);
    pos.z -= sin(pos.y * 1.0) * 0.2 * pow(random.w, 4.0) * pow(uScroll, 3.5);

    pos.xz = mix(pos.xz, vec2(0.0), pow(smoothstep(5.0, -45.0, pos.y), 3.0));

    vOffset = length(pos-decodedPos.xyz);


    vec3 worldPos = vec3(modelMatrix * vec4(pos, 1.0));
    vWorldPos = worldPos;

    float dist = length(worldPos - cameraPosition);
    vDist = dist;
    vUv = uv;

    vRipple = 0.0;//0.5 + sin(length(vWorldPos.xz) * 2.0) * 0.5;

    vec3 viewDir = normalize(cameraPosition - pos);
    vec3 ray = vec3(0.0, 0.0, 0.0) - pos;
    vec3 rayDir = normalize(ray);
    float u = 0.5 + atan(rayDir.z, rayDir.x) / (2.0 * PI);
    float v = 0.5 - asin(rayDir.y) / PI;
    float intensity = smoothstep(5.0, 2.0, length(ray));
    vLightColor = texture2D(tPointColor, position.xy).rgb;
    //vLightColor += ;

    vPos = pos;
    vRandom = random;

    vScale = smoothstep(3.0, 15.0, dist);
    vScale *= 1.0 + (0.5 + sin(time * 5.0 + random.y * 20.0) * 0.5) * 0.3;
    vScale *= mix(0.5, 1.5, random.z);
    vScale *= mix(1.0, 3.0, vRipple);

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = (0.0275) * DPR * 2.0 * vScale * (1000.0 / length(mvPosition.xyz)) * uSizeBias;
    gl_Position = projectionMatrix * mvPosition;
}

#!SHADER: Fragment

#require(range.glsl)
#require(transformUV.glsl)
#require(simplenoise.glsl)
#require(rgb2hsv.fs)
#require(blendmodes.glsl)
#require(shadows.fs)

void main() {
    vec2 uv = vec2(gl_PointCoord.x, 1.0 - gl_PointCoord.y);
    if (length(uv-0.5) > 0.5) discard;
    if (vScale < 0.1) discard;

    vec3 color = vLightColor;
    //color *= 1.0 + vRipple * 0.5;
    //color += vRipple * 0.01;

    vec3 sparkle = vec3(0.4 + sin(time * 3.0 + vRandom.y * 20.0));
    //color += sparkle * pow(vRandom.z, 200.0) * vRipple * 0.5;
    //color = min(vec3(0.9), color);

    float noise = cnoise(vWorldPos*0.5+time*0.15+vWorldPos.y*0.3);

    // Bubble Texture
    vec2 matcapUV = rotateUV(uv, sin(time * 1.0 + vRandom.z * 20.0) * 0.5 + 1.0);
    vec3 matcap = texture2D(tMap, matcapUV).rgb * 1.3;
    //matcap = mix(matcap, vec3(1.0), 0.5 + sin(time + vRandom.x * 20.0) * 0.4);
    color = blendSoftLight(color, matcap, 0.8);
    color = blendOverlay(color, matcap, 0.1);

    color = rgb2hsv(color);
    color.x = mix(color.x, (0.6 + smoothstep(0.8, 1.0, color.x)), vFlowers);
    color.x += noise * 0.03 - 0.03;
    color.x += vCameraPos.y * 0.02 - 0.0;
    color.y *= mix(0.5, 0.8, vRandom.w);
    color = hsv2rgb(color);

    color = mix(color, sparkle, smoothstep(2.0, 0.2, uSparkle) * pow(vRandom.x, 10.0) * 0.5);

    
    color *= mix(0.6, 1.0, smoothstep(15.0, 6.0, vDist));
    //color = mix(color, vec3(1.0, 0.0, 0.0), smoothstep(0.0001, 0.0, vOffset));

    color = pow(color * 1.2, vec3(1.4));
    //color = mix(color, vec3(1.0), vFlowers);


    #drawbuffer Color gl_FragColor = vec4(color, 1.0);
    #drawbuffer WorkRefraction gl_FragColor = vec4(color, 1.0);
    // gl_FragColor.rgb *= crange(getShadow(vPos, 0.01), 0.0, 1.0, 0.3, 1.0);
}