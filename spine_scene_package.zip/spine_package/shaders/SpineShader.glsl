#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tBaseColor;
uniform sampler2D tRefraction;
uniform vec2 uReflection;

#!VARYINGS
varying vec3 vCameraPos;
varying vec4 vWorldPos;

#!SHADER: Vertex

#require(fbr.vs)

void main() {
    vec3 pos = position;
    setupFBR(position);
    vNormal = normalMatrix * normal;
    vCameraPos = cameraPosition;
    vWorldPos = modelMatrix * vec4(position, 1.0);

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}

#!SHADER: Fragment

#require(fbr.fs)
#require(rgb2hsv.fs)
#require(transformUV.glsl)

void main() {
    vec2 uv = vUv;
    uv.x += vWorldPos.x * 0.2;

    vec3 baseColor = texture2D(tBaseColor, uv).rgb;
    vec3 color = getFBR(baseColor, uv);

    vec3 normal = unpackNormalFBR(vEyePos, vWorldNormal, tNormal, uNormalStrength, 1.0, vUv);

    normal.y -= vWorldPos.y * 0.02;

    vec2 screenuv = gl_FragCoord.xy / resolution;
    screenuv += normal.xy * 0.1 * uReflection.x;

    color += texture2D(tRefraction, screenuv).rgb * uReflection.y;

    #drawbuffer Color gl_FragColor = vec4(color, 1.0);
    #drawbuffer WorkRefraction gl_FragColor = vec4(color, 1.0);
}