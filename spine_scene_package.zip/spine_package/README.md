# Active Theory — Spine Scene: Complete Reconstruction Package

This package contains every file needed to recreate the iridescent backbone/spine scene
from activetheory.net/work — the central 3D spine mesh, flower + forest particle clouds,
all PBR textures, GLSL shaders, and exact scene parameters.

---

## DIRECTORY STRUCTURE

```
spine_package/
├── README.md                          ← this file
├── scene_params.json                  ← camera, material, and shader uniforms (exact values)
├── assets/
│   ├── geometry/
│   │   └── spine/
│   │       ├── spine.bin              ← Draco-compressed spine mesh (AT custom format)
│   │       └── spine.json             ← Full float32 geometry fallback (position/normal/uv)
│   ├── particles/
│   │   ├── flower_spine-128.bin       ← Draco PointCloud: flower particle positions+colors
│   │   └── forest-128.bin             ← Draco PointCloud: forest particle positions+colors
│   ├── images/
│   │   ├── pbr/
│   │   │   ├── alien_cracked_2_basecolor.ktx2   ← Spine base color texture (KTX2/Basis)
│   │   │   ├── alien_cracked_2_normal.png        ← Normal map (PNG fallback)
│   │   │   ├── cliffs_MRO.ktx2                  ← Metallic/Roughness/Occlusion (KTX2)
│   │   │   ├── damaged_road_normal.ktx2          ← Normal map for spine (KTX2)
│   │   │   ├── damaged_road_normal.png            ← Normal map (PNG fallback)
│   │   │   ├── damaged_road_mro.png              ← MRO fallback
│   │   │   ├── empty_normal.ktx2                 ← Flat normal placeholder
│   │   │   └── empty_mro.ktx2                    ← Flat MRO placeholder
│   │   ├── particle/
│   │   │   └── matcap3.ktx2           ← Matcap for flower particles (iridescent look)
│   │   └── room/
│   │       └── matcap-test.ktx2       ← Matcap for spine mesh (iridescent/glossy look)
│   ├── fonts/
│   │   ├── NBArchitektStd-Regular.woff2
│   │   └── NBArchitektStd-Bold.woff2
│   ├── decoders/
│   │   ├── draco_decoder.wasm         ← Draco WebAssembly decoder
│   │   ├── draco_wasm_wrapper.js      ← Draco JS wrapper
│   │   ├── basis_transcoder.js        ← KTX2/BasisU transcoder
│   │   └── basis_transcoder.wasm      ← BasisU WebAssembly
│   └── splines_anim4-SPLINES.json     ← Camera/scroll spline animation paths
└── shaders/
    ├── SpineShader.glsl               ← Main spine mesh shader (vert + frag)
    ├── FlowerParticleShader.glsl      ← Flower + forest particle shader (vert + frag)
    ├── fbr.vs                         ← FBR (Fresnel-Based Rendering) vertex lib
    ├── fbr.fs                         ← FBR fragment lib (matcap + PBR microfacet)
    ├── matcap.vs                      ← Matcap UV calculation helper
    ├── rgb2hsv.fs                     ← HSV color space conversion
    ├── transformUV.glsl               ← UV transform helpers (rotate, scale, skew)
    ├── range.glsl                     ← range/crange remapping helpers
    ├── simplenoise.glsl               ← cnoise/fbm noise functions
    ├── blendmodes.glsl                ← Photoshop-style blend modes (softlight, overlay…)
    └── instance.vs                    ← GPU instancing transform helpers
```

---

## BINARY FORMAT: HOW TO LOAD .bin FILES

All `.bin` files use the same Active Theory custom format:

```
[8 bytes]  uint64 little-endian = header_size (N)
[N bytes]  JSON descriptor string (starts with 2 null bytes, then JSON, then Draco magic)
[rest]     Draco-compressed geometry payload
```

**Parse in JavaScript:**
```javascript
async function parseATBin(url) {
  const buf = await fetch(url).then(r => r.arrayBuffer());
  const view = new DataView(buf);
  const headerSize = view.getUint32(0, true); // lower 32 bits is enough

  // JSON starts at byte 10 (8 byte size field + 2 null bytes)
  const jsonBytes = new Uint8Array(buf, 10, headerSize - 2);
  const jsonStr = new TextDecoder().decode(jsonBytes);
  // Trim to valid JSON (stops before Draco magic "DRAC")
  const jsonEnd = jsonStr.indexOf('DRAC') > -1
    ? jsonStr.lastIndexOf('}', jsonStr.indexOf('DRAC')) + 1
    : jsonStr.lastIndexOf('}') + 1;
  const meta = JSON.parse(jsonStr.substring(0, jsonEnd));
  // meta.type: 0 = indexed mesh, 1 = point cloud
  // meta.attributes: [["position",7], ["normal",7], ["uv",7]] etc.

  const dracoStart = 8 + headerSize;
  const dracoBuffer = buf.slice(dracoStart);
  return { meta, dracoBuffer };
}
```

---

## SPINE MESH (spine.bin / spine.json)

- **type 0** = indexed triangular mesh
- **attributes:** position (vec3 float32), normal (vec3 float32), uv (vec2 float32)
- **12,732 vertices**, non-indexed (no index buffer)
- **Bounds:** X[-0.28, 0.27], Y[-0.15, 0.18], Z[-0.24, 0.24]
- The spine.json contains the raw float arrays as a fallback (no Draco needed)

**Load spine.json directly (easiest path):**
```javascript
const geo = new THREE.BufferGeometry();
const data = await fetch('assets/geometry/spine/spine.json').then(r => r.json());
geo.setAttribute('position', new THREE.Float32BufferAttribute(data.position, 3));
geo.setAttribute('normal',   new THREE.Float32BufferAttribute(data.normal, 3));
geo.setAttribute('uv',       new THREE.Float32BufferAttribute(data.uv, 2));
```

**Load spine.bin via Draco (preferred):**
```javascript
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';
const { dracoBuffer } = await parseATBin('assets/geometry/spine/spine.bin');
const loader = new DRACOLoader();
loader.setDecoderPath('assets/decoders/');
loader.decodeDracoFile(dracoBuffer, geometry => { /* use geometry */ });
```

---

## PARTICLE SYSTEMS (flower_spine-128.bin, forest-128.bin)

- **type 1** = point cloud
- **attributes:** positions (vec3 xyz float32), colors (vec3 rgb float32)
- Suffix `-128` = LOD tier (128K particles). Higher res files not included.
- Both are Draco PointCloud encoded

**Load particles:**
```javascript
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';

const { dracoBuffer } = await parseATBin('assets/particles/flower_spine-128.bin');
const loader = new DRACOLoader();
loader.setDecoderPath('assets/decoders/');
// Three.js DRACOLoader auto-detects PointCloud vs Mesh
loader.decodeDracoFile(dracoBuffer, (geometry) => {
  const mat = new THREE.PointsMaterial({
    size: 0.015,
    vertexColors: true,
    sizeAttenuation: true,
    transparent: true,
    depthWrite: false,
  });
  const points = new THREE.Points(geometry, mat);
  scene.add(points);
});
```

---

## TEXTURES: KTX2 LOADING

```javascript
import { KTX2Loader } from 'three/examples/jsm/loaders/KTX2Loader.js';

const ktx2 = new KTX2Loader();
ktx2.setTranscoderPath('assets/decoders/');  // basis_transcoder.js + .wasm
ktx2.detectSupport(renderer);

// Spine matcap (drives the iridescent shimmer)
const matcap = await ktx2.loadAsync('assets/images/room/matcap-test.ktx2');

// Spine base color
const baseColor = await ktx2.loadAsync('assets/images/pbr/alien_cracked_2_basecolor.ktx2');

// Spine MRO (metallic / roughness / occlusion)
const mro = await ktx2.loadAsync('assets/images/pbr/cliffs_MRO.ktx2');

// Spine normal map
const normal = await ktx2.loadAsync('assets/images/pbr/damaged_road_normal.ktx2');
// fallback PNG also included at: assets/images/pbr/damaged_road_normal.png

// Flower particle matcap
const particleMatcap = await ktx2.loadAsync('assets/images/particle/matcap3.ktx2');
```

---

## SPINE MATERIAL — EXACT SHADER UNIFORMS

From `scene_params.json` / UIL config (Element_5_Work):

```javascript
const spineUniforms = {
  tBaseColor:      baseColor,           // alien_cracked_2_basecolor.ktx2
  tMRO:            mro,                 // cliffs_MRO.ktx2
  tMatcap:         matcap,              // matcap-test.ktx2
  tNormal:         normalMap,           // damaged_road_normal.ktx2
  tRefraction:     refractionRT,        // render target from previous frame
  uColor:          new THREE.Color('#d1fff4'),   // light cyan tint
  uLight:          new THREE.Vector4(1, 1, 1, 0.4),  // xyz=direction, w=intensity
  uNormalStrength: 0.19,
  uReflection:     new THREE.Vector2(2.7, 0.85),  // refraction strength, blend
};
```

**The iridescent look** comes from the FBR system in `fbr.fs`:
- Reads `tMRO` for roughness → determines matcap UV spread
- Samples `tMatcap` using screen-space normal reflection (`reflectMatcap` in `matcap.vs`)
- Multiplies baseColor × matcap, adds microfacet specular
- `tRefraction` adds a screen-space refraction pass on top

---

## SPINE INSTANCER

From `SpineInstancer` in app.js:
- Creates **40 instances** of the spine mesh in a `MeshBatch`
- Spacing: `position.y = -0.65 * i + 4` (stacked vertically, 0.65 apart)
- Rotation: `rotation.y = 0.4 * i` (each instance rotated 0.4 rad more than previous)
- The original mesh is hidden, batch is shown

```javascript
const spineGeo = /* loaded from spine.json or spine.bin */;
const spineInstances = [];
for (let i = 0; i < 40; i++) {
  const mesh = new THREE.Mesh(spineGeo, spineMat);
  mesh.position.set(0, -0.65 * i + 4, 0);
  mesh.rotation.y = 0.4 * i;
  scene.add(mesh);
  spineInstances.push(mesh);
}
```

---

## CAMERA

From `scene_params.json` (CAMERA_Element_2_Work):

```javascript
camera.fov = 35;
camera.position.set(0, 0, 2);
camera.rotation.set(0, THREE.MathUtils.degToRad(196.07), 0);  // faces back
// lookAt: [0, 0, -4]
// lerpSpeed: 0.07
// moveXY (mouse parallax): [0, 0]  (no parallax in this scene element)
```

---

## SHADER SYSTEM

The shaders use AT's custom `#!ATTRIBUTES / #!UNIFORMS / #!VARYINGS / #!SHADER:` blocks
and `#require(filename)` for includes. To use them in plain Three.js, inline the required
files manually. The `shaders/` folder contains all files fully extracted.

**SpineShader.glsl** requires:
- `fbr.vs` → vertex setup (vNormal, vWorldNormal, vUv, vMPos, vEyePos)
- `fbr.fs` → getFBR(), unpackNormalFBR(), reflectMatcap() (pulls in matcap.vs)
- `matcap.vs` → reflectMatcap() helper (called inside fbr.fs)
- `rgb2hsv.fs` → rgb2hsv/hsv2rgb
- `transformUV.glsl` → rotateUV, scaleUV etc.

**FlowerParticleShader.glsl** requires:
- `range.glsl` → range/crange
- `simplenoise.glsl` → cnoise
- `blendmodes.glsl` → blendSoftLight, blendOverlay
- `rgb2hsv.fs` → color space
- `transformUV.glsl` → rotateUV

**Key uniforms for FlowerParticleShader:**
```javascript
{
  tPos:          /* GPGPU position texture or placeholder */,
  tLightTexture: /* light texture */,
  tPointColor:   /* per-particle color texture */,
  tMap:          particleMatcap,    // matcap3.ktx2
  uLightPos:     new THREE.Vector3(0, 5, 5),
  uTint:         new THREE.Vector3(1, 1, 1),
  DPR:           window.devicePixelRatio,
  uScroll:       0.0,   // 0–1, drives scroll animation
  uSizeBias:     1.0,
  uAnimate:      1.0,
  uRotate:       0.0,
  uSparkle:      0.0,
  time:          elapsed,
}
```

---

## SCROLL ANIMATION

`splines_anim4-SPLINES.json` = array of spline paths, each is flat `[x,y,z, x,y,z, ...]` triplets.
Used to drive camera and object positions along scroll progress (0–1).
Each spline is sampled by lerping between triplets based on scroll %.

---

## FONT

Custom `NBArchitekt` typeface used for all UI text:
```css
@font-face {
  font-family: 'nbarchitekt';
  src: url('assets/fonts/NBArchitektStd-Regular.woff2') format('woff2');
  font-weight: 400;
}
@font-face {
  font-family: 'nbarchitekt';
  src: url('assets/fonts/NBArchitektStd-Bold.woff2') format('woff2');
  font-weight: 700;
}
```

---

## SCENE COMPOSITION (from screenshot)

```
Black background (#000000)
│
├── WebGL Canvas (full screen)
│   ├── SpineInstancer (40× spine mesh, stacked + rotated)
│   │   └── SpineShader: matcap-test + alien_cracked_2 basecolor + cliffs_MRO + damaged_road_normal
│   ├── Flower Particles (flower_spine-128.bin → Points)
│   │   └── FlowerParticleShader: matcap3 texture, HSV color shift
│   └── Forest Particles (forest-128.bin → Points)
│       └── same FlowerParticleShader, different position data
│
└── DOM Overlay (z-index above canvas)
    ├── Nav: top-right, pill border, "WORK ── CONTACT"
    ├── Phone card LEFT: purple gradient, border-radius 36px, "ELD F" text
    ├── Phone card RIGHT: partial, teal gradient
    └── Chat UI: bottom-left, mix-blend-mode: color-dodge
        ├── "WHAT ARE YOU LOOKING FOR?"
        ├── -> WEBSITES
        ├── -> INSTALLATIONS
        ├── -> XR / VR / AI   ← active (glows white, translateX 10px)
        ├── -> MULTIPLAYER
        ├── -> GAMES
        └── [Ask me anything...] input
```

---

## RENDERING SETUP

```javascript
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;

// Camera
const camera = new THREE.PerspectiveCamera(35, w/h, 0.01, 100);
camera.position.set(0, 0, 2);

// The spine faces away from camera by default
// camera.rotation.y = THREE.MathUtils.degToRad(196.07)
// OR just flip the spine group: spineGroup.rotation.y = Math.PI
```
